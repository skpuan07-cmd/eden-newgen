Basic Concepts
==============

CRUDRequest
-----------

