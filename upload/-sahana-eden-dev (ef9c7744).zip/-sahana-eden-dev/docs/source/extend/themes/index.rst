Adding new themes
=================
