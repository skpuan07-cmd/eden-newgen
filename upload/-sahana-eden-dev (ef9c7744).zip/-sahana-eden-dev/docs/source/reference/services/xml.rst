XML Encoder/Decoder *xml*
=========================

