"""
    Maintenance Tasks for MRCMS

    License: MIT
"""

import datetime

from gluon import current

# =============================================================================
class Daily():
    """ Daily Maintenance Tasks """

    def __call__(self):

        db = current.db
        s3db = current.s3db

        current.log.info("Daily Maintenance MRCMS")

        now = datetime.datetime.utcnow()
        week_past = now - datetime.timedelta(weeks=1)

        # Cleanup Scheduler logs
        table = s3db.scheduler_run
        db(table.start_time < week_past).delete()

        # Cleanup Sync logs
        table = s3db.sync_log
        db(table.timestmp < week_past).delete()

        # Cleanup old sessions
        from core.tools.utils import remove_old_sessions
        remove_old_sessions(ttl=1)

        # Cleanup unverified accounts
        self.cleanup_unverified_accounts()

        # Expire shelter commissions
        self.expire_shelter_commissions()

    # -------------------------------------------------------------------------
    @staticmethod
    def cleanup_unverified_accounts():
        """
            Remove unverified user accounts
        """

        db = current.db
        s3db = current.s3db
        auth = current.auth

        auth_settings = auth.settings

        now = datetime.datetime.utcnow()

        utable = auth_settings.table_user
        mtable = auth_settings.table_membership
        ttable = s3db.auth_user_temp
        ltable = s3db.pr_person_user

        left = [ltable.on(ltable.user_id == utable.id),
                mtable.on(mtable.user_id == utable.id),
                ]

        query = (utable.created_on < now - datetime.timedelta(hours=48)) & \
                (utable.registration_key != None) & \
                (~(utable.registration_key.belongs("", "disabled", "blocked", "pending"))) & \
                (utable.deleted == False) & \
                (ltable.id == None) & \
                (mtable.id == None)

        rows = db(query).select(utable.id,
                                utable.email,
                                left = left,
                                )
        for row in rows:

            email = row.email

            try:
                success = db(ttable.user_id == row.id).delete()
            except Exception:
                success = False
            if not success:
                current.log.warning("Could not delete temp data for user %s" % email)
                continue

            try:
                success = row.delete_record()
            except Exception:
                success = False
            if not success:
                current.log.warning("Could not delete unverified user %s" % email)

            current.log.info("Deleted unverified user account %s" % email)

    # -------------------------------------------------------------------------
    @staticmethod
    def expire_shelter_commissions():
        """
            Check for expired shelter commissions
        """

        today = datetime.datetime.utcnow().date()

        table = current.s3db.cr_shelter_commission
        query = (table.status != "REVOKED") & \
                (table.end_date != None) & \
                (table.end_date < today) & \
                (table.deleted == False)
        current.db(query).update(status = "EXPIRED",
                                 modified_by = table.modified_by,
                                 modified_on = table.modified_on,
                                 )

# END =========================================================================
