"""
    Resource Export Tools

    Copyright: 2009-2022 (c) Sahana Software Foundation

    Permission is hereby granted, free of charge, to any person
    obtaining a copy of this software and associated documentation
    files (the "Software"), to deal in the Software without
    restriction, including without limitation the rights to use,
    copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following
    conditions:

    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
    OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
    NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
    WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
    OTHER DEALINGS IN THE SOFTWARE.
"""

__all__ = ("DataExporter",)

from gluon import current

# =============================================================================
class DataExporter:
    """
        Exporter toolkit
    """

    # -------------------------------------------------------------------------
    @staticmethod
    def csv(resource):
        """
            Export resource as CSV

            Args:
                resource: the resource to export

            Note:
                Export does not include components!

            TODO implement audit
        """

        request = current.request
        response = current.response

        if response:
            servername = ("%s_" % request.env.server_name) if request else ""
            filename = "%s%s.csv" % (servername, resource.tablename)
            from gluon.contenttype import contenttype
            response.headers["Content-Type"] = contenttype(".csv")
            response.headers["Content-disposition"] = "attachment; filename=%s" % filename

        rows = resource.select(None, as_rows=True)
        return str(rows)

    # -------------------------------------------------------------------------
    @staticmethod
    def json(resource,
             start=None,
             limit=None,
             fields=None,
             orderby=None,
             represent=False,
             tooltip=None):
        """
            Export a resource as JSON

            Args:
                resource: the resource to export from
                start: index of the first record to export
                limit: maximum number of records to export
                fields: list of field selectors for fields to include in
                        the export (None for all fields)
                orderby: ORDERBY expression
                represent: whether values should be represented
                tooltip: additional tooltip field, either a field selector
                         or an expression "f(k,v)" where f is a function
                         name that can be looked up from s3db, and k,v are
                         field selectors for the row, f will be called with
                         a list of tuples (k,v) for each row and is expected
                         to return a dict {k:tooltip} => used by
                         filterOptionsS3 to extract onhover-tooltips for
                         Ajax-update of options
        """

        if fields is None:
            # Use json_fields setting, or fall back to list_fields if
            # not defined, or to all readable fields if list_fields is
            # not defined either.
            # Always include the ID field regardless whether it is
            # configured or not => required for S3FilterOptions and
            # similar Ajax lookups.
            fields = resource.list_fields("json_fields", id_column=0)

        if orderby is None:
            orderby = resource.get_config("orderby", None)

        tooltip_function = None
        if tooltip:
            if type(tooltip) is list:
                tooltip = tooltip[-1]
            import re
            match = re.match(r"(\w+)\((\w+),(\w+)\)", tooltip)
            if match:
                function_name, kname, vname = match.groups()
                # Try to resolve the function name
                tooltip_function = current.s3db.get(function_name)
                if tooltip_function:
                    if kname not in fields:
                        fields.append(kname)
                    if vname not in fields:
                        fields.append(vname)
            else:
                if tooltip not in fields:
                    fields.append(tooltip)

        # Get the data
        _rows = resource.select(fields,
                                start=start,
                                limit=limit,
                                orderby=orderby,
                                represent=represent).rows

        # Simplify to plain fieldnames for fields in this table
        tn = "%s." % resource.tablename
        rows = []
        rappend = rows.append
        for _row in _rows:
            row = {}
            for f in _row:
                v = _row[f]
                if tn in f:
                    f = f.split(tn, 1)[1]
                row[f] = v
            rappend(row)

        if tooltip:
            if tooltip_function:
                # Resolve key and value names against the resource
                try:
                    krfield = resource.resolve_selector(kname)
                    vrfield = resource.resolve_selector(vname)
                except (AttributeError, SyntaxError):
                    import sys
                    current.log.error(sys.exc_info()[1])
                else:
                    # Extract key and value fields from each row and
                    # build options dict for function call
                    options = []
                    items = {}
                    for row in rows:
                        try:
                            k = krfield.extract(row)
                        except KeyError:
                            break
                        try:
                            v = vrfield.extract(row)
                        except KeyError:
                            break
                        items[k] = row
                        options.append((k, v))
                    # Call tooltip rendering function
                    try:
                        tooltips = tooltip_function(options)
                    except:
                        import sys
                        current.log.error(sys.exc_info()[1])
                    else:
                        # Add tooltips as "_tooltip" to the corresponding rows
                        if isinstance(tooltips, dict):
                            from ..tools import s3_str
                            for k, v in tooltips.items():
                                if k in items:
                                    items[k]["_tooltip"] = s3_str(v)

            else:
                # Resolve the tooltip field name against the resource
                try:
                    tooltip_rfield = resource.resolve_selector(tooltip)
                except (AttributeError, SyntaxError):
                    import sys
                    current.log.error(sys.exc_info()[1])
                else:
                    # Extract the tooltip field from each row
                    # and add it as _tooltip
                    from ..tools import s3_str
                    for row in rows:
                        try:
                            value = tooltip_rfield.extract(row)
                        except KeyError:
                            break
                        if value:
                            row["_tooltip"] = s3_str(value)

        # Return as JSON
        response = current.response
        if response:
            response.headers["Content-Type"] = "application/json"

        from gluon.serializers import json as jsons
        return jsons(rows)

    # -------------------------------------------------------------------------
    @staticmethod
    def pdf(*args, **kwargs):

        from ..formats import PDFWriter
        return PDFWriter().encode(*args, **kwargs)

    # -------------------------------------------------------------------------
    @staticmethod
    def pdfcard(*args, **kwargs):

        from ..formats import PDFCardWriter
        return PDFCardWriter().encode(*args, **kwargs)

    # -------------------------------------------------------------------------
    @staticmethod
    def shp(*args, **kwargs):

        from ..formats import SHPWriter
        return SHPWriter().encode(*args, **kwargs)

    # -------------------------------------------------------------------------
    @staticmethod
    def svg(*args, **kwargs):

        from ..formats import SVGWriter
        return SVGWriter().encode(*args, **kwargs)

    # -------------------------------------------------------------------------
    @staticmethod
    def xls(*args, **kwargs):

        from ..formats import XLSWriter
        return XLSWriter().encode(*args, **kwargs)

    # -------------------------------------------------------------------------
    @staticmethod
    def xlsx(*args, **kwargs):

        from ..formats import XLSXWriter
        return XLSXWriter.encode(*args, **kwargs)

# End =========================================================================
