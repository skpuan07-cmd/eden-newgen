#!/bin/bash
# Push Eden to GitHub — run this on your machine
set -e

echo "=== Eden → GitHub Push ==="

# Initialize git
git init
git add -A
git commit -m "Eden NewGen: FastAPI + AI modules + Next.js UI + Docker + Helm

- FastAPI backend: 49 endpoints, 121 tests
- AI registration: OCR, Voice, Bulk import, NLQ
- JWT auth + 2FA (TOTP)
- Person/Org/Event CRUD
- PWA offline-first + Push notifications + QR check-in
- Webhooks: Line/SMS/Telegram
- Docker + docker-compose.prod.yml
- Helm chart for Kubernetes
- Next.js frontend: login + dashboard
- 5-phase migration from web2py to FastAPI
- Real z-ai API integration (GLM-4-plus)"

git branch -M main

# Add remote
git remote add origin https://github.com/skpuan07-cmd/eden-newgen.git

# Push
echo ""
echo "Pushing to GitHub..."
git push -u origin main

echo ""
echo "✅ Done! https://github.com/skpuan07-cmd/eden-newgen"
