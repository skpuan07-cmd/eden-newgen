# Eden Unit Tests
#
# To run this script use:
# python web2py.py -S eden -M -R applications/eden/modules/unit_tests/core/methods/crud.py
#
import json
import unittest

from io import StringIO

from gluon import current
from gluon.storage import Storage

from unit_tests import run_suite

from core import BasicCRUD

# =============================================================================
class ValidateTests(unittest.TestCase):
    """ Test BasicCRUD/validate """

    def setUp(self):

        s3db = current.s3db

        # Create a fake request
        self.resource = s3db.resource("org_organisation")
        self.request = Storage(prefix="org",
                               name="organisation",
                               resource=self.resource,
                               table=self.resource.table,
                               tablename=self.resource.tablename,
                               method="validate",
                               get_vars=Storage(),
                               representation="json",
                               http="GET")

    # -------------------------------------------------------------------------
    def testValidateMainTable(self):
        """ Test successful main table validation """

        request = self.request
        crud = BasicCRUD()

        jsonstr = """{"name":"TestOrganisation", "acronym":"TO"}"""
        request.body = StringIO(jsonstr)

        output = crud.validate(request)

        self.assertTrue(isinstance(output, str))
        data = json.loads(output)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(len(data), 2)
        self.assertTrue("name" in data)
        name = data["name"]
        self.assertTrue(isinstance(name, dict))
        self.assertTrue("value" in name)
        self.assertTrue("text" in name)
        self.assertTrue(isinstance(name["text"], str))
        self.assertFalse("_error" in name)

        acronym = data["acronym"]
        self.assertTrue(isinstance(acronym, dict))
        self.assertTrue("value" in acronym)
        self.assertTrue("text" in acronym)
        self.assertTrue(isinstance(acronym["text"], str))
        self.assertFalse("_error" in acronym)

    # -------------------------------------------------------------------------
    def testValidateMainTableError(self):
        """ Test error in main table validation """

        request = self.request
        crud = BasicCRUD()

        jsonstr = """{"name":"", "acronym":"TO"}"""
        request.body = StringIO(jsonstr)

        output = crud.validate(request)

        self.assertTrue(isinstance(output, str))
        data = json.loads(output)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(len(data), 2)
        self.assertTrue("name" in data)
        name = data["name"]
        self.assertTrue(isinstance(name, dict))
        self.assertTrue("value" in name)
        self.assertFalse("text" in name)
        self.assertTrue("_error" in name)

        acronym = data["acronym"]
        self.assertTrue(isinstance(acronym, dict))
        self.assertTrue("value" in acronym)
        self.assertTrue("text" in acronym)
        self.assertTrue(isinstance(acronym["text"], str))
        self.assertFalse("_error" in acronym)

    # -------------------------------------------------------------------------
    def testValidateComponentTable(self):
        """ Test successful component validation """

        request = self.request
        crud = BasicCRUD()

        jsonstr = """{"name":"TestOffice"}"""
        request.body = StringIO(jsonstr)
        request.get_vars["component"] = "office"

        output = crud.validate(request)

        self.assertTrue(isinstance(output, str))
        data = json.loads(output)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(len(data), 1)
        self.assertTrue("name" in data)
        name = data["name"]
        self.assertTrue(isinstance(name, dict))
        self.assertTrue("value" in name)
        self.assertTrue("text" in name)
        self.assertTrue(isinstance(name["text"], str))
        self.assertFalse("_error" in name)

    # -------------------------------------------------------------------------
    def testValidateComponentTableFailure(self):
        """ Test error in component validation """

        request = self.request
        crud = BasicCRUD()

        jsonstr = """{"name":"", "acronym":"test"}"""
        request.body = StringIO(jsonstr)
        request.get_vars["component"] = "office"

        output = crud.validate(request)

        self.assertTrue(isinstance(output, str))
        data = json.loads(output)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(len(data), 2)

        self.assertTrue("name" in data)
        name = data["name"]
        self.assertTrue(isinstance(name, dict))
        self.assertTrue("value" in name)
        self.assertFalse("text" in name)
        self.assertTrue("_error" in name)

        self.assertTrue("acronym" in data)
        acronym = data["acronym"]
        self.assertTrue(isinstance(acronym, dict))
        self.assertTrue("value" in acronym)
        self.assertFalse("text" in acronym)
        self.assertTrue("_error" in acronym)

    # -------------------------------------------------------------------------
    def testTypeConversionFeature(self):
        """ Check that values get converted into the field type during validation """

        s3db = current.s3db

        # Create a fake request
        resource = s3db.resource("project_organisation")
        request = Storage(prefix="project",
                          name="organisation",
                          resource=resource,
                          table=resource.table,
                          tablename=resource.tablename,
                          method="validate",
                          get_vars=Storage(),
                          representation="json",
                          http="GET")

        crud = BasicCRUD()

        jsonstr = """{"organisation_id":"1", "role":"1"}"""
        request.body = StringIO(jsonstr)

        output = crud.validate(request)
        self.assertTrue(isinstance(output, str))
        data = json.loads(output)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(len(data), 2)

        self.assertTrue("role" in data)
        role = data["role"]
        self.assertTrue(isinstance(role, dict))
        self.assertTrue("value" in role)
        self.assertTrue(isinstance(role["value"], int))

# =============================================================================
if __name__ == "__main__":

    run_suite(
        ValidateTests,
    )

# END ========================================================================
